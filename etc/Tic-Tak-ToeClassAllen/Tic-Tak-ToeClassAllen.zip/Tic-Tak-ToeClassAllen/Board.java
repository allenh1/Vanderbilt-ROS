
/**
 * All data and code related to a tic-tac-toe board.
 * 
 * @author Hunter Allen 
 * @version November 16, 2010
 */
public class Board
{    
    private Square Board[] = new Square[9];
    
   public void setX(int square)
   {
       Board[square].makeX();
    }//set square as an X.
   
   public void setO(int square)
   {
       Board[square].makeO();
    }//set the square as an O.
    
   public void showBoard()
   {
       System.out.print("|"+Board[0]+"|"+Board[1]+"|"+Board[2]+"|");
    }//print out the board.
   
   //hasSameThree(String side int a, int b, int c)
   
   //isFull()
}
